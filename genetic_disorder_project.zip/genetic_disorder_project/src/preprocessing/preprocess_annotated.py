import os
import pandas as pd
import numpy as np
import statistics
import re

DELIMITERS = ['/', ';', ':', '|']
SPECIAL_SYMBOLS_PATTERN = r'[<>+=/]'

def detect_delimiter_issues(df):
    delimiter_issues = {}
    for col in df.columns:
        if df[col].dtype == object:
            sample = df[col].dropna().astype(str).sample(min(100, len(df[col].dropna())))
            for delim in DELIMITERS:
                if sample.str.contains(delim).any():
                    delimiter_issues.setdefault(col, []).append(delim)
    return delimiter_issues

def clean_cell_value_strict(value, delimiter):
    if pd.isna(value) or not isinstance(value, str) or delimiter not in value:
        return value
    parts = [p.strip() for p in value.split(delimiter) if p.strip() not in ['', '.']]
    if not parts:
        return np.nan
    try:
        nums = list(map(float, parts))
        return round(sum(nums) / len(nums), 4)
    except ValueError:
        try:
            return statistics.mode(parts)
        except statistics.StatisticsError:
            return parts[0]  # fallback

def clean_dataframe_delimiters_strict(df, delimiter_issues):
    cleaned_df = df.copy()
    for col, delimiters in delimiter_issues.items():
        for delim in delimiters:
            cleaned_df[col] = cleaned_df[col].apply(lambda val: clean_cell_value_strict(val, delim))
    return cleaned_df

def remove_commas_from_cells(df):
    for col in df.columns:
        if df[col].dtype == object:
            df[col] = df[col].astype(str).str.replace(',', '', regex=False)
    return df

def drop_special_symbol_columns(df):
    drop_cols = []
    for col in df.columns:
        try:
            sample = df[col].dropna().astype(str).sample(min(100, len(df[col].dropna())))
            if sample.str.contains(SPECIAL_SYMBOLS_PATTERN).any():
                drop_cols.append(col)
        except:
            continue
    return df.drop(columns=drop_cols, errors='ignore'), drop_cols

def preprocess_tsv_to_csv(tsv_path, output_csv_path):
    df = pd.read_csv(tsv_path, sep='\t', dtype=str)
    print(f"✅ Loaded TSV: {tsv_path} → shape: {df.shape}")

    delimiter_issues = detect_delimiter_issues(df)
    df = clean_dataframe_delimiters_strict(df, delimiter_issues)
    print(f"✅ Cleaned delimiter columns: {list(delimiter_issues.keys())}")

    df = remove_commas_from_cells(df)
    print("✅ Commas removed from string fields")

    df, dropped = drop_special_symbol_columns(df)
    print(f"🧹 Dropped columns with special symbols: {dropped}")

    df.to_csv(output_csv_path, index=False)
    print(f"✅ Final CSV saved: {output_csv_path}")
    return output_csv_path
