import os
import subprocess
import logging
import threading
from datetime import datetime
from .base_annotator import BaseAnnotator
from concurrent.futures import ThreadPoolExecutor

class DbNSFPAnnotator(BaseAnnotator):
    def __init__(self, dbnsfp_dir=None, genome_version="hg38", memory="5g", num_threads=4):

        # args:
        #     dbnsfp_dir (str): Path to dbNSFP database directory
        #     genome_version (str): Genome version (hg18/hg19/hg38)
        #     memory (str): Memory allocation for Java

        self.dbnsfp_dir = dbnsfp_dir or os.path.join(os.getcwd(), 'data', 'dbnsfp')
        self.genome_version = genome_version
        self.memory = memory
        self.num_threads = num_threads
        self.lock = threading.Lock() #TTTT
        self.setup_logging()
        
    def setup_logging(self):
        # Set up logging configuration
        log_dir = 'logs'
        os.makedirs(log_dir, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_file = os.path.join(log_dir, f'dbnsfp_annotation_{timestamp}.log')
        
        self.logger = logging.getLogger('DbNSFPAnnotator')
        self.logger.setLevel(logging.INFO)
        
        handlers = [
            logging.FileHandler(log_file),
            logging.StreamHandler()
        ]
        
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        for handler in handlers:
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
            
    def setup(self):
        # CHECK 1: Verify dbNSFP files and Java environment
        self.logger.info("Setting up DbNSFP annotator...")
        
        # CHECK 2: Check Java installation
        try:
            result = subprocess.run(['java', '-version'], 
                                 capture_output=True, 
                                 text=True, 
                                 check=True)
            self.logger.info("Java installation verified")
        except subprocess.CalledProcessError as e:
            raise RuntimeError("Java not found. Please install Java 1.8 or later")
            
        # CHECK 3: Verify dbNSFP files
        required_files = ['search_dbNSFP49a.class']
        for file in required_files:
            file_path = os.path.join(self.dbnsfp_dir, file)
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"Required file not found: {file_path}")
                
        self.logger.info("DbNSFP setup completed successfully")
            

    def _split_vcf(self, input_file, num_chunks, output_file):
        """Splits the VCF file into smaller chunks for parallel processing."""
        with open(input_file, 'r') as f:
            lines = f.readlines()

        # header = [line for line in lines if line.startswith("#")]
        variants = [line for line in lines if not line.startswith("#")]
        chunk_size = len(variants) // num_chunks
        chunk_files = []

        for i in range(num_chunks):
            chunk_file = os.path.join(output_file, f'chunk_{i}.vcf')
            with open(chunk_file, 'w') as cf:
                # cf.writelines(header)
                # chunks = [variants[i:i + chunk_size] for i in range(0, len(variants), chunk_size)]
                cf.writelines(variants[i * chunk_size: (i + 1) * chunk_size])
            chunk_files.append(chunk_file)

        return chunk_files
     
    def annotate(self, input_file, output_file):

        # Annotate variants using dbNSFP
        
        # args:
        #     input_file (str): Path to input VCF file
        #     output_file (str): Path to output file

        self.logger.info(f"Starting annotation: {input_file} -> {output_file}")
        
        try:
            # Change to dbNSFP directory to ensure proper file access
            original_dir = os.getcwd()
            os.chdir(self.dbnsfp_dir)
            
            # Build command
            cmd = [
                'java',
                f'-Xmx{self.memory}',
                'search_dbNSFP49a',
                '-i', input_file,
                '-o', output_file,
                '-v', self.genome_version,
                '-p'  # Preserve VCF columns
            ]
            
            with self.lock:
                print(f"Executing: {' '.join(cmd)}")

            # Execute command
            self.logger.info(f"Executing command: {' '.join(cmd)}")
            result = subprocess.run(cmd, 
                                 capture_output=True, 
                                 text=True, 
                                 check=True)
            
            self.logger.info("Annotation completed successfully")
            
        except subprocess.CalledProcessError as e:
            self.logger.error(f"Annotation failed: {e.stderr}")
            raise RuntimeError(f"DbNSFP annotation failed: {e.stderr}")
            
        finally:
            os.chdir(original_dir)

#TTTT
    def annotate_parallel(self, input_file, output_file, num_chunks=4):
        chunk_files = self._split_vcf(input_file, num_chunks, output_file)
        op_files = [os.path.join(output_file, f'annotated_chunk_{i}.csv') for i in range(num_chunks)]

        with ThreadPoolExecutor(max_workers=self.num_threads) as executor:
            executor.map(self.annotate, chunk_files, op_files)
        
        merged_output = os.path.join(output_file, 'final_annotated_variants.csv')
        self._merge_files(op_files, merged_output)
        return merged_output

    def _merge_files(self, files, output_file):
        """Merges multiple annotated CSV files into a single file."""
        with open(output_file, 'w') as out_f:
            for file in files:
                with open(file, 'r') as in_f:
                    out_f.write(in_f.read())

    def cleanup(self):
        """Clean up resources"""
        # Close log handlers
        for handler in self.logger.handlers[:]:
            handler.close()
            self.logger.removeHandler(handler)

# configuration for app.py
class DbNSFPConfig:
    """Configuration settings for DbNSFP integration"""
    
    DBNSFP_DIR = os.path.join(os.getcwd(), 'data', 'dbnsfp')
    GENOME_VERSION = "hg38"  # Default genome version
    JAVA_MEMORY = "5g"      # Default Java memory allocation
    
    @classmethod
    def validate_config(cls):

        # to validate DbNSFP configuration

        if not os.path.exists(cls.DBNSFP_DIR):
            raise FileNotFoundError(f"DbNSFP directory not found: {cls.DBNSFP_DIR}")
            
        java_file = os.path.join(cls.DBNSFP_DIR, 'search_dbNSFP49a.class')
        if not os.path.exists(java_file):
            raise FileNotFoundError(f"DbNSFP Java program not found: {java_file}")